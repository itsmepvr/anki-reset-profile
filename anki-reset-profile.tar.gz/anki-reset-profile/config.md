## Reset Profile

-   Resets and removes all decks, notetypes, tags and media in profile
